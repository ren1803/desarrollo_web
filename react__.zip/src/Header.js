import React from "react";

function Header() {
    return (
        <div>
            <h1> Hello to everyone!! </h1><br/><h3> I'm glad to be here </h3>
        </div>
    );
}

export default Header;