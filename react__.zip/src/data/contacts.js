const contacts = [{
        img: "https://e.rpp-noticias.io/normal/2016/06/05/593159_159278.jpg",
        name: "Jack Black",
        phone: "+123456654321",
        email: "myemail@mail.com",
    },
    {
        img: "https://cdn.britannica.com/51/188751-050-D4E1CFBC/Beyonce-2010.jpg",
        name: "Beyonce",
        phone: "+95476823",
        email: "beyonce@superstar.com",
    },
    {
        img: "https://upload.wikimedia.org/wikipedia/commons/thumb/3/3a/Elton_John_Cannes_2019.jpg/640px-Elton_John_Cannes_2019.jpg",
        name: "Elton John",
        phone: "+365892",
        email: "elton@john.com",
    },
];
export default contacts;