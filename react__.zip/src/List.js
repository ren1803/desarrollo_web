import React from "react";

function List() {
    return (
        <div>
            <ul>
            <li> Bohemian Rhapsody </li>
            <li> I'm still standing </li>
            <li> Thriller </li>
            </ul>
        </div>
    );
}

export default List;